#
# CopyrightMicrosoft Corporation. All rights reserved."
#

configuration PrepS2D
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        #[String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),
		[String]$DomainNetbiosName1=(Get-NetBIOSName -DomainName $DomainName),
		[String]$DomainNetbiosName="gtca",

        [Int]$RetryCount=5,
        [Int]$RetryIntervalSec=20
    )

	$DebugPreference = "Continue"
	Write-Debug "VS - PrepS2D.ps1:  param DomainName = $($DomainName)"
	Write-Debug "VS - PrepS2D.ps1:  Derived from Get-NetBIOSName function -- DomainNetbiosName1 = $($DomainNetbiosName1)"
	Write-Debug "VS - PrepS2D.ps1:  DomainNetbiosName from DomainName = $($DomainNetbiosName)"

    Import-DscResource -ModuleName xComputerManagement,xActiveDirectory

	Write-Debug "VS - PrepS2D.ps1:  Admincreds.UserName = $($Admincreds.UserName)"

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

	Write-Debug "VS - PrepS2D.ps1:  DomainCreds.UserName = $($DomainCreds.UserName)"

    Node localhost
    {
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature FS
        {
            Name = "FS-FileServer"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
       {
			#Write-Debug "VS - PrepS2D.ps1:  Inside mof xWaitForADDomain DscForestWait DomainName"
			#Write-Debug "VS - PrepS2D.ps1:  xWaitForADDomain DscForestWait DomainName = $($DomainName)"
			#Write-Debug "VS - PrepS2D.ps1:  xWaitForADDomain DscForestWait DomainUserCredential.UserName = $($DomainCreds.UserName)"
            DomainName = $DomainName 
            DomainUserCredential = $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"
        }

		#Write-Debug "VS - PrepS2D.ps1:  Outside xWaitForADDomain"
		#Write-Debug "VS - PrepS2D.ps1:  xWaitForADDomain.DomainName = $($xWaitForADDomain.DomainName)"
		#Write-Debug "VS - PrepS2D.ps1:  xWaitForADDomain.DomainUserCredential.UserName = $($xWaitForADDomain.DomainUserCredential.UserName)"

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }
    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}